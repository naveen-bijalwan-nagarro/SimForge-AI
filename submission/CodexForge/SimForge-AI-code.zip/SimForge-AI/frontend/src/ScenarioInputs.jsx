import React, { useEffect, useRef, useState } from "react";
import { api } from "./client";

export function VoiceDictation({ onText, disabled }) {
  const [language, setLanguage] = useState("en-IN");
  const [consent, setConsent] = useState(false);
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState("");
  const [message, setMessage] = useState("");
  const recognition = useRef(null);
  const append = useRef(onText);
  append.current = onText;
  const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
  useEffect(
    () => () => {
      const current = recognition.current;
      if (current) {
        current.onresult = current.onerror = current.onend = null;
        current.abort();
      }
    },
    [],
  );
  function start() {
    setMessage("");
    try {
      recognition.current?.abort();
      const current = new Speech();
      recognition.current = current;
      current.lang = language;
      current.continuous = true;
      current.interimResults = true;
      const committed = new Set();
      current.onresult = (event) => {
        if (recognition.current !== current) return;
        let preview = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          if (result.isFinal && !committed.has(i)) {
            committed.add(i);
            append.current(result[0].transcript);
          } else if (!result.isFinal) preview += result[0].transcript + " ";
        }
        setInterim(preview.trim());
      };
      current.onerror = (event) => {
        if (recognition.current !== current) return;
        setMessage(
          `Dictation stopped: ${event.error}. Check microphone permission/network, or type instead.`,
        );
        setListening(false);
        setInterim("");
        current.abort();
      };
      current.onend = () => {
        if (recognition.current !== current) return;
        setListening(false);
        setInterim("");
        recognition.current = null;
      };
      current.start();
      setListening(true);
    } catch {
      setMessage(
        "Dictation could not start. Allow microphone access on HTTPS/localhost, or type instead.",
      );
      setListening(false);
    }
  }
  return (
    <section className="scenario-input" aria-label="Voice dictation controls">
      <h3>Write with your voice (optional)</h3>
      <p className="tiny">
        Your browser may send audio to its speech service; offline operation is
        not guaranteed. SimForge stores no audio. Do not dictate sensitive
        information. Review the editable text before generating; speech never
        publishes or executes commands.
      </p>
      {!Speech && (
        <p role="status">
          Voice dictation is not supported in this browser. Type your
          description instead.
        </p>
      )}
      <label>
        Dictation language
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
          disabled={listening}
        >
          <option value="en-IN">English (India)</option>
          <option value="en-US">English (US)</option>
          <option value="hi-IN">Hindi (India)</option>
        </select>
      </label>
      <label className="voice-consent">
        <input
          type="checkbox"
          checked={consent}
          disabled={listening}
          onChange={(e) => setConsent(e.target.checked)}
        />{" "}
        I agree to browser speech processing
      </label>
      {listening ? (
        <button
          className="secondary"
          onClick={() => recognition.current?.stop()}
        >
          Stop dictation
        </button>
      ) : (
        <button
          className="secondary"
          disabled={!Speech || !consent || disabled}
          onClick={start}
        >
          Start voice dictation
        </button>
      )}
      {listening && (
        <p role="status">
          Listening… {interim || "Speak your training goal and workflow."}
        </p>
      )}
      {message && <p role="alert">{message}</p>}
    </section>
  );
}

function encoded(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1]);
    reader.onerror = () =>
      reject(new Error("Could not read the selected document"));
    reader.readAsDataURL(file);
  });
}

const isImage = (file) => /\.(png|jpe?g|webp)$/i.test(file.name);

function ImageDescription({ file, value, onChange }) {
  const [url, setUrl] = useState("");
  useEffect(() => {
    const local = URL.createObjectURL(file);
    setUrl(local);
    return () => URL.revokeObjectURL(local);
  }, [file]);
  return (
    <div className="document-reference">
      <img
        src={url}
        alt={`Local preview of ${file.name}`}
        style={{ maxWidth: "100%", maxHeight: 180, objectFit: "contain" }}
      />
      <label>
        Reviewed description for {file.name}
        <textarea
          value={value || ""}
          maxLength={6000}
          rows={3}
          onChange={(e) => onChange(e.target.value)}
        />
      </label>
    </div>
  );
}

export function ScenarioDocuments({ selected, onSelect, disabled }) {
  const [documents, setDocuments] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [pending, setPending] = useState([]);
  const [descriptions, setDescriptions] = useState({});
  async function upload(event) {
    const files = Array.from(event.target.files || []);
    event.target.value = "";
    if (!files.length) return;
    setError("");
    setMessage("");
    if (
      files.length > 8 ||
      files.some((f) => f.size > 2 * 1024 * 1024) ||
      files.reduce((n, f) => n + f.size, 0) > 8 * 1024 * 1024
    ) {
      setError("Select up to 8 files, at most 2 MiB each and 8 MiB total.");
      return;
    }
    if (files.some(isImage)) {
      setPending(files);
      setDescriptions({});
      return;
    }
    await send(files);
  }
  async function send(files) {
    setBusy(true);
    setError("");
    try {
      const result = await api("/scenario-documents", {
        files: await Promise.all(
          files.map(async (file) => ({
            name: file.name,
            content: await encoded(file),
            description: descriptions[file.name] || "",
          })),
        ),
      });
      setDocuments((old) => [...result.documents, ...old]);
      setPending([]);
      setDescriptions({});
      onSelect(
        [...new Set([...selected, ...result.documents.map((d) => d.id)])].slice(
          0,
          8,
        ),
      );
      setMessage(
        `${result.documents.length} documents extracted locally. Review the checked files before generating.`,
      );
      if (result.errors.length)
        setError(
          result.errors.map((e) => `${e.name}: ${e.message}`).join(" · "),
        );
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <section
      className="scenario-input"
      aria-label="Scenario reference documents"
    >
      <h3>Upload scenario documents</h3>
      <p className="tiny">
        PDF, DOCX, TXT, Markdown, CSV, JSON, PNG, JPG or WebP. Up to 8 files; 2
        MiB each, 8 MiB total.
      </p>
      <p className="tiny">
        Local pattern screening covers extracted text and reviewed image
        descriptions, not image pixels or scanned PDF pages. Review each preview:
        zero recognized matches does not mean PII-free. Nothing reaches the
        model until you generate; manual JSON does not read references.
      </p>
      <label>
        Scenario documents (multiple files)
        <input
          type="file"
          multiple
          accept=".pdf,.docx,.txt,.md,.csv,.json,.png,.jpg,.jpeg,.webp"
          disabled={busy || disabled}
          onChange={upload}
        />
      </label>
      {busy && <p role="status">Extracting document text locally…</p>}
      {pending.length > 0 && (
        <section aria-label="Review image references">
          <p>
            Describe the relevant workflow or observations in each image. Pixels
            stay in this browser preview and local verification; only your
            screened description reaches the model. Names or identifiers inside
            pixels are not automatically detected.
          </p>
          {pending.filter(isImage).map((file) => (
            <ImageDescription
              key={file.name}
              file={file}
              value={descriptions[file.name]}
              onChange={(text) =>
                setDescriptions((old) => ({ ...old, [file.name]: text }))
              }
            />
          ))}
          <button
            className="secondary"
            disabled={
              busy ||
              disabled ||
              pending
                .filter(isImage)
                .some((f) => (descriptions[f.name] || "").trim().length < 30)
            }
            onClick={() => send(pending)}
          >
            Upload reviewed references
          </button>
          <button
            className="secondary"
            disabled={busy}
            onClick={() => setPending([])}
          >
            Cancel image upload
          </button>
        </section>
      )}
      {error && (
        <p className="error-banner" role="alert">
          {error}
        </p>
      )}
      {message && <p role="status">{message}</p>}
      <p className="tiny">
        {selected.length}/8 references selected for this draft. Only checked
        files are included when you preview or generate. Long references are
        excerpted fairly into a 24,000-character context budget.
      </p>
      <details className="reference-library">
        <summary>
          Review uploaded references ({selected.length} selected)
        </summary>
        {!documents.length && (
          <p className="tiny">Upload files above to review their extracted text.</p>
        )}
        {documents.map((d) => (
          <article className="document-reference" key={d.id}>
              <label className="voice-consent">
                <input
                  type="checkbox"
                  checked={selected.includes(d.id)}
                  disabled={
                    disabled ||
                    (!selected.includes(d.id) && selected.length >= 8)
                  }
                  onChange={(e) =>
                    onSelect(
                      e.target.checked
                        ? [...selected, d.id]
                        : selected.filter((id) => id !== d.id),
                    )
                  }
                />{" "}
                {d.name}
              </label>
              <small>
                {d.text.length.toLocaleString()} extracted characters ·{" "}
                {d.redactions
                  ? d.redactions.total
                    ? `${d.redactions.total} recognized match${d.redactions.total === 1 ? "" : "es"} redacted`
                    : "no recognized matches"
                  : "screening receipt unavailable"}{" "}
                in {d.input_type === "image_description" ? "reviewed description" : "extracted text"}
              </small>
              <small>
                Detector: {d.redactions?.engine || "not recorded for this reference"}
              </small>
              {Object.entries(d.redactions?.entities || {}).map(([type, count]) => (
                <span className="badge" key={type}>
                  {type} → &lt;{type}&gt; × {count}
                </span>
              ))}
              {d.warnings.map((warning) => (
                <p className="tiny" key={warning}>
                  {warning}
                </p>
              ))}
              <details>
                <summary>Preview extracted text: {d.name}</summary>
                <pre className="document-text">{d.text}</pre>
              </details>
          </article>
        ))}
      </details>
    </section>
  );
}

export function ScenarioCleanup({ onChanged }) {
  const [preview, setPreview] = useState(null);
  const [confirmation, setConfirmation] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function refresh() {
    setPreview(await api("/scenario-cleanup"));
  }
  useEffect(() => {
    refresh().catch((e) => setError(e.message));
  }, []);
  async function act(fn) {
    setBusy(true);
    setError("");
    try {
      await fn();
      await refresh();
      setConfirmation("");
      await onChanged?.();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <details
      className="panel padded"
      onToggle={(e) => {
        if (e.currentTarget.open) refresh().catch((x) => setError(x.message));
      }}
    >
      <summary>Fresh demo: archive previous custom scenarios</summary>
      <p>
        Archive old custom publications, draft records and generation history.
        They disappear from the active queue/library and their old
        notifications/assignments are hidden. Built-in exercises, learner runs,
        prepared datasets and source documents remain. Existing saved
        runs/environments still work. Archives can be restored.
      </p>
      {preview && (
        <>
          <p>
            {preview.counts.scenario} custom publications ·{" "}
            {preview.counts.scenario_draft} draft records ·{" "}
            {preview.counts.authoring_job} generation jobs
          </p>
          <ul>
            {preview.records.map((r) => (
              <li key={r.id}>
                {r.title} ({r.kind})
              </li>
            ))}
          </ul>
          <label>
            Type ARCHIVE to confirm cleanup
            <input
              value={confirmation}
              onChange={(e) => setConfirmation(e.target.value)}
            />
          </label>
          <button
            className="secondary"
            disabled={
              busy || confirmation !== "ARCHIVE" || !preview.records.length
            }
            onClick={() =>
              act(async () => {
                const result = await api("/scenario-cleanup", {
                  token: preview.token,
                  confirmation,
                });
                setMessage(
                  `${result.count} records archived. Your next draft starts a fresh publication queue.`,
                );
              })
            }
          >
            Archive previous scenarios and drafts
          </button>
          {preview.history.map((batch) => (
            <p key={batch.id}>
              {new Date(batch.at * 1000).toLocaleString()} · {batch.count}{" "}
              archived records ·{" "}
              {batch.restored ? (
                "restored"
              ) : (
                <button
                  className="secondary"
                  disabled={busy}
                  onClick={() =>
                    act(async () => {
                      const result = await api(
                        `/scenario-cleanup/${batch.id}/restore`,
                        {},
                      );
                      setMessage(`${result.count} records restored.`);
                    })
                  }
                >
                  Restore archive {batch.id.slice(0, 6)}
                </button>
              )}
            </p>
          ))}
        </>
      )}
      {error && (
        <p role="alert" className="error-banner">
          {error}
        </p>
      )}
      {message && <p role="status">{message}</p>}
    </details>
  );
}
